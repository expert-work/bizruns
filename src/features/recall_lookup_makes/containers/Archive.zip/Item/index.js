import React from 'react';
import { connect } from 'react-redux';
import { Recall_lookup_makeItem } from '../../components/Item';
import { reduxForm, getFormValues } from 'redux-form';
import { validate } from './validation';
import * as Recall_lookup_makesAction from '../../actions';
import { ITEM_FORM } from '../../constants';

const mapStateToProps = (state, { navigation }) => {
    const {
        recall_lookup_makes: { loading },
        global: { language, taxTypes },
    } = state;

    const item = navigation.getParam('item', {});

    const type = navigation.getParam('type');
    const discountPerItem = navigation.getParam('discount_per_item');
    const taxPerItem = navigation.getParam('tax_per_item');

    const isLoading = loading.editItemLoading || loading.removeItemLoading

    return {
        loading: isLoading,
        formValues: getFormValues(ITEM_FORM)(state) || {},
        itemId: item && (item.item_id || item.id),
        taxTypes,
        currency: navigation.getParam('currency'),
        language: language,
        discountPerItem,
        taxPerItem,
        type,
        initialValues: {
            price: 0,
            quantity: 1,
            discount_type: 'none',
            discount: 0,
            taxes: [],
            ...item
        },
    };
};

const mapDispatchToProps = {
    addItem: Recall_lookup_makesAction.addItem,
    setRecall_lookup_makeItems: Recall_lookup_makesAction.setRecall_lookup_makeItems,
    removeRecall_lookup_makeItem: Recall_lookup_makesAction.removeRecall_lookup_makeItem,
};

//  Redux Forms
const addItemReduxForm = reduxForm({
    form: ITEM_FORM,
    validate,
})(Recall_lookup_makeItem);

//  connect
const Recall_lookup_makeItemContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)(addItemReduxForm);

Recall_lookup_makeItemContainer.navigationOptions = () => ({
    header: null,
});

export default Recall_lookup_makeItemContainer;

