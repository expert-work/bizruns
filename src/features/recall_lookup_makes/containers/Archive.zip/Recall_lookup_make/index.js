import React from 'react';
import { connect } from 'react-redux';
import { Recall_lookup_make } from '../../components/Recall_lookup_make';
import { reduxForm, getFormValues } from 'redux-form';
import { validate } from './validation';
import * as Recall_lookup_makesAction from '../../actions';
import { RECALL_LOOKUP_MAKE_FORM, RECALL_LOOKUP_MAKE_DETAIL } from '../../constants';
import moment from 'moment';
import * as CustomersAction from '../../../customers/actions';

const mapStateToProps = (state, { navigation }) => {
    const {
        global: { language, taxTypes },
        recall_lookup_makes: { loading, recall_lookup_makeItems, recall_lookup_makeData, items },
        customers: { customers },
    } = state;

    const { recall_lookup_make = null, nextRecall_lookup_makeNumber, recall_lookup_makeTemplates } = recall_lookup_makeData;

    let type = navigation.getParam('type')

    let isLoading = loading.initRecall_lookup_makeLoading || (type === RECALL_LOOKUP_MAKE_DETAIL && !recall_lookup_make)
        || !nextRecall_lookup_makeNumber

    return {
        initLoading: isLoading,
        loading: loading.recall_lookup_makeLoading,
        recall_lookup_makeItems,
        recall_lookup_makeData,
        items,
        type,
        customers,
        itemsLoading: loading.itemsLoading,
        language,
        formValues: getFormValues(RECALL_LOOKUP_MAKE_FORM)(state) || {},
        taxTypes,
        initialValues: !isLoading ? {
            expiry_date: moment().add(7, 'days'),
            recall_lookup_make_date: moment(),
            recall_lookup_make_number: nextRecall_lookup_makeNumber,
            discount_type: 'fixed',
            discount: 0,
            taxes: [],
            recall_lookup_make_template_id: recall_lookup_makeTemplates[0] && recall_lookup_makeTemplates[0].id,
            ...recall_lookup_make,
            customer: recall_lookup_make && recall_lookup_make.user,
            template: recall_lookup_make && recall_lookup_make.recall_lookup_make_template,
        } : null
    };
};

const mapDispatchToProps = {
    getCreateRecall_lookup_make: Recall_lookup_makesAction.getCreateRecall_lookup_make,
    createRecall_lookup_make: Recall_lookup_makesAction.createRecall_lookup_make,
    getItems: Recall_lookup_makesAction.getItems,
    getEditRecall_lookup_make: Recall_lookup_makesAction.getEditRecall_lookup_make,
    detailRecall_lookup_make: Recall_lookup_makesAction.detailRecall_lookup_make,
    removeRecall_lookup_makeItems: Recall_lookup_makesAction.removeRecall_lookup_makeItems,
    removeRecall_lookup_make: Recall_lookup_makesAction.removeRecall_lookup_make,
    convertToInvoice: Recall_lookup_makesAction.convertToInvoice,
    clearRecall_lookup_make: Recall_lookup_makesAction.clearRecall_lookup_make,
    convertToInvoice: Recall_lookup_makesAction.convertToInvoice,
    changeRecall_lookup_makeStatus: Recall_lookup_makesAction.changeRecall_lookup_makeStatus,
    getCustomers: CustomersAction.getCustomers,
};

//  Redux Forms
const addRecall_lookup_makeReduxForm = reduxForm({
    form: RECALL_LOOKUP_MAKE_FORM,
    validate,
})(Recall_lookup_make);

//  connect
const Recall_lookup_makeContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)(addRecall_lookup_makeReduxForm);

Recall_lookup_makeContainer.navigationOptions = () => ({
    header: null,
});

export default Recall_lookup_makeContainer;
