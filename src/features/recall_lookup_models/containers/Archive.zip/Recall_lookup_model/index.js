import React from 'react';
import { connect } from 'react-redux';
import { Recall_lookup_model } from '../../components/Recall_lookup_model';
import { reduxForm, getFormValues } from 'redux-form';
import { validate } from './validation';
import * as Recall_lookup_modelsAction from '../../actions';
import { RECALL_LOOKUP_MODEL_FORM, RECALL_LOOKUP_MODEL_DETAIL } from '../../constants';
import moment from 'moment';
import * as CustomersAction from '../../../customers/actions';

const mapStateToProps = (state, { navigation }) => {
    const {
        global: { language, taxTypes },
        recall_lookup_models: { loading, recall_lookup_modelItems, recall_lookup_modelData, items },
        customers: { customers },
    } = state;

    const { recall_lookup_model = null, nextRecall_lookup_modelNumber, recall_lookup_modelTemplates } = recall_lookup_modelData;

    let type = navigation.getParam('type')

    let isLoading = loading.initRecall_lookup_modelLoading || (type === RECALL_LOOKUP_MODEL_DETAIL && !recall_lookup_model)
        || !nextRecall_lookup_modelNumber

    return {
        initLoading: isLoading,
        loading: loading.recall_lookup_modelLoading,
        recall_lookup_modelItems,
        recall_lookup_modelData,
        items,
        type,
        customers,
        itemsLoading: loading.itemsLoading,
        language,
        formValues: getFormValues(RECALL_LOOKUP_MODEL_FORM)(state) || {},
        taxTypes,
        initialValues: !isLoading ? {
            expiry_date: moment().add(7, 'days'),
            recall_lookup_model_date: moment(),
            recall_lookup_model_number: nextRecall_lookup_modelNumber,
            discount_type: 'fixed',
            discount: 0,
            taxes: [],
            recall_lookup_model_template_id: recall_lookup_modelTemplates[0] && recall_lookup_modelTemplates[0].id,
            ...recall_lookup_model,
            customer: recall_lookup_model && recall_lookup_model.user,
            template: recall_lookup_model && recall_lookup_model.recall_lookup_model_template,
        } : null
    };
};

const mapDispatchToProps = {
    getCreateRecall_lookup_model: Recall_lookup_modelsAction.getCreateRecall_lookup_model,
    createRecall_lookup_model: Recall_lookup_modelsAction.createRecall_lookup_model,
    getItems: Recall_lookup_modelsAction.getItems,
    getEditRecall_lookup_model: Recall_lookup_modelsAction.getEditRecall_lookup_model,
    detailRecall_lookup_model: Recall_lookup_modelsAction.detailRecall_lookup_model,
    removeRecall_lookup_modelItems: Recall_lookup_modelsAction.removeRecall_lookup_modelItems,
    removeRecall_lookup_model: Recall_lookup_modelsAction.removeRecall_lookup_model,
    convertToInvoice: Recall_lookup_modelsAction.convertToInvoice,
    clearRecall_lookup_model: Recall_lookup_modelsAction.clearRecall_lookup_model,
    convertToInvoice: Recall_lookup_modelsAction.convertToInvoice,
    changeRecall_lookup_modelStatus: Recall_lookup_modelsAction.changeRecall_lookup_modelStatus,
    getCustomers: CustomersAction.getCustomers,
};

//  Redux Forms
const addRecall_lookup_modelReduxForm = reduxForm({
    form: RECALL_LOOKUP_MODEL_FORM,
    validate,
})(Recall_lookup_model);

//  connect
const Recall_lookup_modelContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)(addRecall_lookup_modelReduxForm);

Recall_lookup_modelContainer.navigationOptions = () => ({
    header: null,
});

export default Recall_lookup_modelContainer;
